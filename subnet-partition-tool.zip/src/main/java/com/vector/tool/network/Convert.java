package com.vector.tool.network;

public class Convert {
    public static String ToString(int value, int toBase) {
        switch (toBase) {
            case 2:
                return Integer.toBinaryString(value & 0xFF + 0x100);
            case 8:
                return Integer.toOctalString(value & 0xFF + 0x100);
            case 10:
                return Integer.toString(value & 0xFF + 0x100);
            case 16:
                return Integer.toHexString(value & 0xFF + 0x100);
            default:
                return "";
        }
    }

    public static int ToInt32(String str, int toBase) {
        return Integer.parseInt(str, toBase);
    }

    public static int ToByte(String intStr) {
        return Integer.parseInt(intStr, 10);
    }
}
