package com.vector.tool.network;

public class Utils {
    public static String PadLeft(String str, int count, char add) {
        for (int i = str.length(); i < count; i++) {
            str = add + str;
        }
        return str;
    }

    public static String PadRight(String str, int count, char add) {
        for (int i = str.length(); i < count; i++) {
            str = str + add;
        }
        return str;
    }
}
