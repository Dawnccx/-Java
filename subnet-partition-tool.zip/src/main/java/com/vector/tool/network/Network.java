package com.vector.tool.network;

import jdk.nashorn.internal.runtime.regexp.joni.Regex;
import sun.nio.ch.Net;

import java.util.regex.Pattern;

public class Network {
    //匹配IP地址的正则表达式
    public static final String MATCH_IP_ADDRESS_REGULAR_EXPRESSION = "^((2[0-4]\\d|25[0-5]|[01]?\\d\\d?)\\.){3}(2[0-4]\\d|25[0-5]|[01]?\\d\\d?)$";
    //网络号 子网掩码
    private int[] networkID;
    //默认前缀
    private int defaultPrefix, prefix;
    //第一个可用主机的地址 最后一个可用主机的地址 广播地址
    private int[] firstHost, lastHost, broadcast;
    //可用主机数
    private int hostsAvailable;
    public int[] getNetworkID() {
        return networkID;
    }
    public int[] getBroadcast() {
        return broadcast;
    }
    public int[] getFirstHost() {
        return firstHost;
    }
    public int[] getLastHost() {
        return lastHost;
    }
    public int getDefaultPrefix() {
        return defaultPrefix;
    }
    public int getHostsAvailable() {
        return hostsAvailable;
    }
    public int getPrefix() {
        return prefix;
    }
    public void setBroadcast(int[] broadcast) {
        this.broadcast = broadcast;
    }
    public void setDefaultPrefix(int defaultPrefix) {
        this.defaultPrefix = defaultPrefix;
    }
    public void setFirstHost(int[] firstHost) {
        this.firstHost = firstHost;
    }
    public void setHostsAvailable(int hostsAvailable) {
        this.hostsAvailable = hostsAvailable;
    }
    public void setLastHost(int[] lastHost) {
        this.lastHost = lastHost;
    }
    public void setNetworkID(int[] networkID) {
        this.networkID = networkID;
    }
    public void setPrefix(int prefix) {
        this.prefix = prefix;
    }

    /// <summary>
    /// 构造函数
    /// </summary>
    /// <param name="ipStr"></param>
    /// <param name="prefix"></param>
    /// <param name="availableHost"></param>
    /// <param name="firstHost"></param>
    /// <param name="lastHost"></param>
    /// <param name="broadcast"></param>
    public Network(String ipStr, int prefix, int availableHost, String firstHost, String lastHost, String broadcast) {
        networkID = getByteByDottedDecimal(ipStr);
        this.prefix = prefix;
        this.defaultPrefix = getDefaultNetworkPrefix(ipStr);
        this.firstHost = getByteByDottedDecimal(firstHost);
        this.lastHost = getByteByDottedDecimal(lastHost);
        this.broadcast = getByteByDottedDecimal(broadcast);
        this.hostsAvailable = availableHost;
    }

    /// <summary>
    /// 通过二进制获取点分十进制
    /// </summary>
    /// <param name="data">ip地址的二进制形式</param>
    /// <returns>如果合法那么返回点分十进制形式的IP地址，否则返回null</returns>
    public static String getDottedDecimalByByte(int[] data) {
        //如果不是一个4字节（32位）的，那么直接return
        if (data == null)
            return null;
        if (data.length != 4)
            return null;

        //计算四个部分的十进制形式
        String first = Convert.ToString(data[0], 10);
        String second = Convert.ToString(data[1], 10);
        String third = Convert.ToString(data[2], 10);
        String fourth = Convert.ToString(data[3], 10);

        //拼接成点分十进制形式
        String ipAddress = String.format("%s.%s.%s.%s", first, second, third, fourth);

        return ipAddress;
    }

    /// <summary>
    /// 通过点分十进制获取其二进制
    /// </summary>
    /// <param name="data"></param>
    /// <returns></returns>
    public static int[] getByteByDottedDecimal(String ipStr) {
        //如果字符串为空或者不负责点分十进制IP地址表示形式的直接return空
        if (ipStr == null)
            return null;
//        if (!Pattern.matches(ipStr, MATCH_IP_ADDRESS_REGULAR_EXPRESSION))
//            return null;

        String[] ipPortion = ipStr.split("\\.");

        //计算各部分的二进制并合并为一个
        int first = Convert.ToByte(ipPortion[0]);
        int second = Convert.ToByte(ipPortion[1]);
        int third = Convert.ToByte(ipPortion[2]);
        int fourth = Convert.ToByte(ipPortion[3]);

        //合并
        int[] ipAddress = new int[]{first, second, third, fourth};

        return ipAddress;
    }

    /// <summary>
    /// 根据IP地址获取默认网络前缀
    /// </summary>
    /// <returns>不合法 -1;D类地址和E类地址 0;A类地址 8;B类地址 16;C类地址 24</returns>
    public static int getDefaultNetworkPrefix(String ipStr) {
        int[] ipBytes = getByteByDottedDecimal(ipStr);
        if (ipBytes == null)
            return -1;

        String firstByteBinaryStr = Utils.PadLeft(Convert.ToString(ipBytes[0], 2), 8, '0');

        char[] firstByteBinaryArray = firstByteBinaryStr.toCharArray();

        if (firstByteBinaryArray[0] == '0') {
            //A类地址 8位网络前缀
            return 8;
        } else if (firstByteBinaryArray[0] == '1' && firstByteBinaryArray[1] == '0') {
            //B类地址 16位网络前缀
            return 16;
        } else if (firstByteBinaryArray[0] == '1' && firstByteBinaryArray[1] == '1' && firstByteBinaryArray[2] == '0') {
            //C类地址 24位网络前缀
            return 24;
        } else {
            //D类地址和E类地址 多播地址和保留地址
            return 0;
        }
    }

    public static Network[] DivideSubnet(String ipStr, int dividedPrefix) {

        if(!(dividedPrefix >= 0 && dividedPrefix <= 32)){
            return null;
        }

        //为了方便，首先将IP地址字符串转换为二进制形式
        int[] ipBytes = Network.getByteByDottedDecimal(ipStr);

        //1101110
        //1010010
        if (ipBytes == null) {
            System.out.printf("IP地址不合法");
            return null;
        }

        if(ipBytes.length != 4){
            return null;
        }

        for(int i = 0;i < ipBytes.length;i++){
            if(!(ipBytes[i] >= 0 && ipBytes[i] <= 255)){
                return null;
            }
        }


        //计算划分后有几个二进制位
        int defaultPrefix = Network.getDefaultNetworkPrefix(ipStr);
        if (defaultPrefix <= 0) {
            System.out.printf("defaultPrefix:" + defaultPrefix);
            System.out.printf(defaultPrefix == 0 ? "D类地址和E类地址" : "IP地址不合法");
            return null;
        }

        if(!(dividedPrefix >= defaultPrefix)){
            return null;
        }

        //借用了几个二进制位
        int borrowedCount = dividedPrefix - defaultPrefix;
        //Console.WriteLine("borrowedCount : " + borrowedCount);

        //网络号部分
        int[] networkID = null;
        if (defaultPrefix == 8) {
            networkID = new int[]{ipBytes[0]};
        } else if (defaultPrefix == 16) {
            networkID = new int[]{ipBytes[0], ipBytes[1]};
        } else {
            networkID = new int[]{ipBytes[0], ipBytes[1], ipBytes[2]};
        }

        Network[] subnets = new Network[(int) Math.pow(2, borrowedCount)];

        //计算新的子网
        //从全0到全1(2的n次方,n是借用的二进制位数)
        for (int i = 0; i < subnets.length; i++) {
            //子网的二进制字符串
            String subnetNetworkIDBinaryStr = "";

            //借用的部分
            String borrowedStr = Utils.PadLeft(Convert.ToString(i, 2), borrowedCount, '0');

            //网络号部分
            for (int j = 0; j < networkID.length; j++) {
                subnetNetworkIDBinaryStr += Utils.PadLeft(Convert.ToString(networkID[j], 2), 8, '0');
            }

            //追加上借用的网络号部分
            subnetNetworkIDBinaryStr += borrowedStr;

            //首位主机 主机地址最后一位是1，其余位都是0
            String subnetFirstHost = subnetNetworkIDBinaryStr + Utils.PadLeft("1", 32 - dividedPrefix, '0');
            //末尾主机 主机地址最后一位是0，其余位都是1
            String subnetLastHost = subnetNetworkIDBinaryStr + Utils.PadLeft("0", 32 - dividedPrefix, '1');
            //广播地址 主机地址全都是1
            String subnetBroadcast = subnetNetworkIDBinaryStr + Utils.PadLeft("1", 32 - dividedPrefix, '1');
            //在右边补0
            subnetNetworkIDBinaryStr = Utils.PadRight(subnetNetworkIDBinaryStr, 32, '0');
            int availableHost = (int) Math.pow(2, 32 - dividedPrefix) - 2;

            //计算各个部分并整合
            ipStr = getIPByByteString(subnetNetworkIDBinaryStr);
            subnetFirstHost = getIPByByteString(subnetFirstHost);
            subnetLastHost = getIPByByteString(subnetLastHost);
            subnetBroadcast = getIPByByteString(subnetBroadcast);

            subnets[i] = new Network(ipStr, dividedPrefix, availableHost, subnetFirstHost, subnetLastHost, subnetBroadcast);
        }

        return subnets;
    }

    public static String getIPByByteString(String byteStr) {
        //计算各个部分
        String first = byteStr.substring(0, 8);
        String second = byteStr.substring(8, 16);
        String third = byteStr.substring(16, 24);
        String fourth = byteStr.substring(24, 32);

        int firstIP = Convert.ToInt32(first, 2);
        int secondIP = Convert.ToInt32(second, 2);
        int thirdIP = Convert.ToInt32(third, 2);
        int fourthIP = Convert.ToInt32(fourth, 2);

        String ipStr = String.format("%d.%d.%d.%d", firstIP, secondIP, thirdIP, fourthIP);
        return ipStr;
    }
}
