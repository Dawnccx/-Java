package com.vector.tool;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InternetToolApplication {

    public static void main(String[] args) {
        SpringApplication.run(InternetToolApplication.class, args);
    }

}
