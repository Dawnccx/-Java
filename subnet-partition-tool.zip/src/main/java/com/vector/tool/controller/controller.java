package com.vector.tool.controller;

import com.vector.tool.network.Network;
import com.vector.tool.network.Utils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;


@Controller
public class controller {
    @ResponseBody
    @RequestMapping("/tool1")
    public String tool1(String ip1, String ip2, String ip3, String ip4, String ip9, Model model) {
        String ipStr = String.format("%s.%s.%s.%s",ip1,ip2,ip3,ip4);

        System.out.printf("prefix %s\n",ip9);
        Network[] subnets = Network.DivideSubnet(ipStr, Integer.parseInt(ip9));

        if(subnets == null){
            return "输入的IP地址或者前缀不合法\n";
        }
        StringBuilder resStr = new StringBuilder();
        resStr.append(ipStr + " / " + ip9 + " 划分子网\n");
        resStr.append("子网掩码         " + getNetworkMask(subnets[0].getDefaultPrefix()) + "\n");

        String ipType;
        switch(Network.getDefaultNetworkPrefix(ipStr)){
            case 0:
                ipType = "D类地址和E类地址";
                break;
            case 8:
                ipType = "A类";
                break;
            case 16:
                ipType = "B类";
                break;
            case 24:
                ipType = "C类";
                break;
            default:
                ipType = "不合法的IP地址";
                break;
        }
        resStr.append(ipType + "IP地址\n");
        resStr.append("子网数量         " + subnets.length + "\n\n");
        for (int i = 0; i < subnets.length; i++) {
            Network subnet = subnets[i];
            resStr.append("***********************************\n");
            resStr.append("网络地址         " + Network.getDottedDecimalByByte(subnet.getNetworkID()) + " / " + subnet.getPrefix() + "\n");
            resStr.append("子网掩码         " + getNetworkMask(subnets[0].getPrefix()) + "\n");
            resStr.append("首位主机         " + Network.getDottedDecimalByByte(subnet.getFirstHost()) + "\n");
            resStr.append("末尾主机         " + Network.getDottedDecimalByByte(subnet.getLastHost()) + "\n");
            resStr.append("广播地址         " + Network.getDottedDecimalByByte(subnet.getBroadcast()) + "\n");
            resStr.append("可用主机         " + subnet.getHostsAvailable() + "\n");
            resStr.append("***********************************\n\n");
        }
        return resStr.toString();
    }

    public static String getNetworkMask(int prefix){
        String maskStr;
        maskStr = Utils.PadLeft("",prefix,'1');
        maskStr = Utils.PadRight(maskStr,32,'0');
        return Network.getIPByByteString(maskStr);
    }


}
