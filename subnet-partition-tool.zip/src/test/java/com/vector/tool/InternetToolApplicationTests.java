package com.vector.tool;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InternetToolApplicationTests {

    @Test
    void contextLoads() {

    }

    @Test
    void Ten() {
        //将十进制数换成八位的二进制数(字符串)
        int num = 255;
        String a = Integer.toBinaryString(num);
        while (a.length() < 8) {
            a = '0' + a;
        }
        System.out.println(a);
    }
}
